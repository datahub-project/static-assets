---
sidebar_position: 54
title: DataHubPersona
slug: /generated/metamodel/entities/datahubpersona
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/generated/metamodel/entities/dataHubPersona.md
---
# DataHubPersona
## Aspects

### dataHubPersonaInfo
Placeholder aspect for persona type info
<details>
<summary>Schema</summary>

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataHubPersonaInfo"
  },
  "name": "DataHubPersonaInfo",
  "namespace": "com.linkedin.persona",
  "fields": [],
  "doc": "Placeholder aspect for persona type info"
}
```
</details>

## Relationships

### Incoming
These are the relationships stored in other entity's aspects
- IsPersona

   - Corpuser via `corpUserEditableInfo.persona`
## [Global Metadata Model](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
![Global Graph](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
