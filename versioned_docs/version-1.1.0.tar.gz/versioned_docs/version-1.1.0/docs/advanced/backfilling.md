---
title: Backfilling Search Index & Graph DB
slug: /advanced/backfilling
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/advanced/backfilling.md
---
# Backfilling Search Index & Graph DB

WIP
