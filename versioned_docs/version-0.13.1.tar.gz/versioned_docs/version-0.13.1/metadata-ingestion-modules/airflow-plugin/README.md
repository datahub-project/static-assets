---
title: Datahub Airflow Plugin
slug: /metadata-ingestion-modules/airflow-plugin
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/metadata-ingestion-modules/airflow-plugin/README.md
---
# Datahub Airflow Plugin

See [the DataHub Airflow docs](/docs/lineage/airflow) for details.

## Developing

See the [developing docs](/docs/next/metadata-ingestion/developing/).
