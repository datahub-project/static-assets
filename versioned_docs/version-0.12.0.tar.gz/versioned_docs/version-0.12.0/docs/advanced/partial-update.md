---
title: Supporting Partial Aspect Update
slug: /advanced/partial-update
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/advanced/partial-update.md
---
# Supporting Partial Aspect Update

WIP
