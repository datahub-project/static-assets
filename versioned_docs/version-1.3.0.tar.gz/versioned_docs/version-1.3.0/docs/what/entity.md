---
title: Entities
slug: /what/entity
custom_edit_url: 'https://github.com/datahub-project/datahub/blob/master/docs/what/entity.md'
---
# Entities

This page has been moved. Please refer to [The Metadata Model](../modeling/extending-the-metadata-model.md) for details on
the metadata model.
