---
sidebar_position: 29
title: DataHubView
slug: /generated/metamodel/entities/datahubview
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/generated/metamodel/entities/dataHubView.md
---
# DataHubView
## Aspects

### dataHubViewInfo
Information about a DataHub View. -- TODO: Understand whether an entity type filter is required.
<details>
<summary>Schema</summary>

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataHubViewInfo"
  },
  "name": "DataHubViewInfo",
  "namespace": "com.linkedin.view",
  "fields": [
    {
      "Searchable": {
        "fieldType": "TEXT_PARTIAL"
      },
      "type": "string",
      "name": "name",
      "doc": "The name of the View"
    },
    {
      "type": [
        "null",
        "string"
      ],
      "name": "description",
      "default": null,
      "doc": "Description of the view"
    },
    {
      "Searchable": {},
      "type": {
        "type": "enum",
        "symbolDocs": {
          "GLOBAL": "A global view, which all users can see and use.",
          "PERSONAL": "A view private for a specific person."
        },
        "name": "DataHubViewType",
        "namespace": "com.linkedin.view",
        "symbols": [
          "PERSONAL",
          "GLOBAL"
        ]
      },
      "name": "type",
      "doc": "The type of View"
    },
    {
      "type": {
        "type": "record",
        "name": "DataHubViewDefinition",
        "namespace": "com.linkedin.view",
        "fields": [
          {
            "type": {
              "type": "array",
              "items": "string"
            },
            "name": "entityTypes",
            "doc": "The Entity Types in the scope of the View."
          },
          {
            "type": {
              "type": "record",
              "name": "Filter",
              "namespace": "com.linkedin.metadata.query.filter",
              "fields": [
                {
                  "type": [
                    "null",
                    {
                      "type": "array",
                      "items": {
                        "type": "record",
                        "name": "ConjunctiveCriterion",
                        "namespace": "com.linkedin.metadata.query.filter",
                        "fields": [
                          {
                            "type": {
                              "type": "array",
                              "items": {
                                "type": "record",
                                "name": "Criterion",
                                "namespace": "com.linkedin.metadata.query.filter",
                                "fields": [
                                  {
                                    "type": "string",
                                    "name": "field",
                                    "doc": "The name of the field that the criterion refers to"
                                  },
                                  {
                                    "type": "string",
                                    "name": "value",
                                    "doc": "The value of the intended field"
                                  },
                                  {
                                    "type": {
                                      "type": "array",
                                      "items": "string"
                                    },
                                    "name": "values",
                                    "default": [],
                                    "doc": "Values. one of which the intended field should match\nNote, if values is set, the above \"value\" field will be ignored"
                                  },
                                  {
                                    "type": {
                                      "type": "enum",
                                      "symbolDocs": {
                                        "ANCESTORS_INCL": "Represent the relation: URN field matches any nested parent in addition to the given URN",
                                        "CONTAIN": "Represent the relation: String field contains value, e.g. name contains Profile",
                                        "DESCENDANTS_INCL": "Represent the relation: URN field any nested children in addition to the given URN",
                                        "END_WITH": "Represent the relation: String field ends with value, e.g. name ends with Event",
                                        "EQUAL": "Represent the relation: field = value, e.g. platform = hdfs",
                                        "EXISTS": "Represents the relation: field exists and is non-empty, e.g. owners is not null and != [] (empty)",
                                        "GREATER_THAN": "Represent the relation greater than, e.g. ownerCount > 5",
                                        "GREATER_THAN_OR_EQUAL_TO": "Represent the relation greater than or equal to, e.g. ownerCount >= 5",
                                        "IEQUAL": "Represent the relation: field = value and support case insensitive values, e.g. platform = hdfs",
                                        "IN": "Represent the relation: String field is one of the array values to, e.g. name in [\"Profile\", \"Event\"]",
                                        "IS_NULL": "Represent the relation: field is null, e.g. platform is null",
                                        "LESS_THAN": "Represent the relation less than, e.g. ownerCount < 3",
                                        "LESS_THAN_OR_EQUAL_TO": "Represent the relation less than or equal to, e.g. ownerCount <= 3",
                                        "RELATED_INCL": "Represent the relation: URN field matches any nested child or parent in addition to the given URN",
                                        "START_WITH": "Represent the relation: String field starts with value, e.g. name starts with PageView"
                                      },
                                      "name": "Condition",
                                      "namespace": "com.linkedin.metadata.query.filter",
                                      "symbols": [
                                        "CONTAIN",
                                        "END_WITH",
                                        "EQUAL",
                                        "IEQUAL",
                                        "IS_NULL",
                                        "EXISTS",
                                        "GREATER_THAN",
                                        "GREATER_THAN_OR_EQUAL_TO",
                                        "IN",
                                        "LESS_THAN",
                                        "LESS_THAN_OR_EQUAL_TO",
                                        "START_WITH",
                                        "DESCENDANTS_INCL",
                                        "ANCESTORS_INCL",
                                        "RELATED_INCL"
                                      ],
                                      "doc": "The matching condition in a filter criterion"
                                    },
                                    "name": "condition",
                                    "default": "EQUAL",
                                    "doc": "The condition for the criterion, e.g. EQUAL, START_WITH"
                                  },
                                  {
                                    "type": "boolean",
                                    "name": "negated",
                                    "default": false,
                                    "doc": "Whether the condition should be negated"
                                  }
                                ],
                                "doc": "A criterion for matching a field with given value"
                              }
                            },
                            "name": "and",
                            "doc": "A list of and criteria the filter applies to the query"
                          }
                        ],
                        "doc": "A list of criterion and'd together."
                      }
                    }
                  ],
                  "name": "or",
                  "default": null,
                  "doc": "A list of disjunctive criterion for the filter. (or operation to combine filters)"
                },
                {
                  "type": [
                    "null",
                    {
                      "type": "array",
                      "items": "com.linkedin.metadata.query.filter.Criterion"
                    }
                  ],
                  "name": "criteria",
                  "default": null,
                  "doc": "Deprecated! A list of conjunctive criterion for the filter. If \"or\" field is provided, then this field is ignored."
                }
              ],
              "doc": "The filter for finding a record or a collection of records"
            },
            "name": "filter",
            "doc": "The filter criteria, which represents the view itself"
          }
        ],
        "doc": "A View definition."
      },
      "name": "definition",
      "doc": "The view itself"
    },
    {
      "Searchable": {
        "/actor": {
          "fieldName": "createdBy",
          "fieldType": "URN"
        },
        "/time": {
          "fieldName": "createdAt",
          "fieldType": "DATETIME"
        }
      },
      "type": {
        "type": "record",
        "name": "AuditStamp",
        "namespace": "com.linkedin.common",
        "fields": [
          {
            "type": "long",
            "name": "time",
            "doc": "When did the resource/association/sub-resource move into the specific lifecycle stage represented by this AuditEvent."
          },
          {
            "java": {
              "class": "com.linkedin.common.urn.Urn"
            },
            "type": "string",
            "name": "actor",
            "doc": "The entity (e.g. a member URN) which will be credited for moving the resource/association/sub-resource into the specific lifecycle stage. It is also the one used to authorize the change."
          },
          {
            "java": {
              "class": "com.linkedin.common.urn.Urn"
            },
            "type": [
              "null",
              "string"
            ],
            "name": "impersonator",
            "default": null,
            "doc": "The entity (e.g. a service URN) which performs the change on behalf of the Actor and must be authorized to act as the Actor."
          },
          {
            "type": [
              "null",
              "string"
            ],
            "name": "message",
            "default": null,
            "doc": "Additional context around how DataHub was informed of the particular change. For example: was the change created by an automated process, or manually."
          }
        ],
        "doc": "Data captured on a resource/association/sub-resource level giving insight into when that resource/association/sub-resource moved into a particular lifecycle stage, and who acted to move it into that specific lifecycle stage."
      },
      "name": "created",
      "doc": "Audit stamp capturing the time and actor who created the View."
    },
    {
      "Searchable": {
        "/time": {
          "fieldName": "lastModifiedAt",
          "fieldType": "DATETIME"
        }
      },
      "type": "com.linkedin.common.AuditStamp",
      "name": "lastModified",
      "doc": "Audit stamp capturing the time and actor who last modified the View."
    }
  ],
  "doc": "Information about a DataHub View. -- TODO: Understand whether an entity type filter is required."
}
```
</details>

## Relationships

### Incoming
These are the relationships stored in other entity's aspects
- viewedWith

   - GlobalSettings via `globalSettingsInfo.views.defaultView`
## [Global Metadata Model](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
![Global Graph](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
