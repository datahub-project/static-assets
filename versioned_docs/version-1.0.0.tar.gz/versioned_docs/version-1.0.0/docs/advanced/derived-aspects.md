---
title: Derived Aspects
slug: /advanced/derived-aspects
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/advanced/derived-aspects.md
---
# Derived Aspects

WIP
