---
title: Managed DataHub
slug: /saas
custom_edit_url: 'https://github.com/datahub-project/datahub/blob/master/docs/saas.md'
---
# DataHub SaaS

Sign up for fully managed, hassle-free and secure SaaS service for DataHub, provided by [Acryl Data](https://www.acryl.io/).

<p>
<a
    className="button button--primary button--lg"
    href="https://www.acryldata.io/datahub-beta" 
    target="_blank" >
    Sign up
</a>
</p>

Refer to [Managed Datahub Exclusives](/docs/managed-datahub/managed-datahub-overview.md) for more information. 
