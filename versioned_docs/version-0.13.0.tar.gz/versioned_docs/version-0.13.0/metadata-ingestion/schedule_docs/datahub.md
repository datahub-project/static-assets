---
title: Using DataHub
slug: /metadata-ingestion/schedule_docs/datahub
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/metadata-ingestion/schedule_docs/datahub.md
---
# Using DataHub

[UI Ingestion](../../docs/ui-ingestion.md) can be used to schedule metadata ingestion through DataHub.
