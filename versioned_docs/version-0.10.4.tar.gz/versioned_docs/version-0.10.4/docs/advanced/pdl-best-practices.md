---
title: PDL Best Practices
slug: /advanced/pdl-best-practices
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/advanced/pdl-best-practices.md
---

# PDL Best Practices

WIP
