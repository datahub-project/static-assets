---
title: Snowflake Configuration
description: >-
  Configure DataHub UI ingestion to connect to Snowflake using the dedicated
  DataHub user and roles created in the previous step.
sidebar_label: Snowflake Configuration
slug: /quick-ingestion-guides/snowflake/configuration
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/quick-ingestion-guides/snowflake/configuration.md
---

# Configuring Your Snowflake Connector to DataHub

Now that you have created a DataHub-specific user with the relevant roles in Snowflake in [the prior step](setup.md), it's now time to set up a connection via the DataHub UI.

:::note Migrating an existing source?
If you already ingest from Snowflake with username + password auth, follow the [key-pair migration guide](migrate-to-key-pair-auth.md) instead of recreating the source — it switches the auth mode in place without resetting your ingestion state.
:::

## Configure Secrets

1. Within DataHub, navigate to the **Ingestion** tab in the top, right corner of your screen

<p align="center">
  <img width="75%" alt="Navigate to the &quot;Ingestion Tab&quot;" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_ingestion_button.png"/>
</p>

:::note
If you do not see the Ingestion tab, please contact your DataHub admin to grant you the correct permissions
:::

2. Navigate to the **Secrets** tab and click **Create new secret**

<p align="center">
   <img width="75%" alt="Secrets Tab" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_secrets_tab.png"/>
</p>

3. Create a Private Key secret

This will securely store the Snowflake private key (the `snowflake_key.p8` you generated in [Setup](setup.md)) within DataHub.

- Enter a name like `SNOWFLAKE_PRIVATE_KEY` - we will use this later to refer to the secret
- Paste the full PEM content of the private key, including the `-----BEGIN PRIVATE KEY-----` / `-----END PRIVATE KEY-----` markers and newlines, into the secret value
- Optionally add a description
- Click **Create**

:::note Passphrase-protected key?
If your private key is encrypted, also create a `SNOWFLAKE_PRIVATE_KEY_PASSWORD` secret holding the passphrase. You'll reference both secrets in the recipe below.
:::

The **Create new secret** form has three fields: a **Name** (use `SNOWFLAKE_PRIVATE_KEY`), a **Value** (paste the full PEM content of `snowflake_key.p8`, including the `-----BEGIN PRIVATE KEY-----` / `-----END PRIVATE KEY-----` markers and newlines), and an optional **Description**. Click **Create** to save it.

## Configure Recipe

4. Navigate to the **Sources** tab and click **Create new source**

<p align="center">
  <img width="75%" alt="Click &quot;Create new source&quot;" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_click_create_new_source_button.png"/>
</p>

5. Select Snowflake

<p align="center">
  <img width="70%" alt="Select Snowflake from the options" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_snowflake_source.png"/>
</p>

6. Fill out the Snowflake Recipe

Enter the Snowflake Account Identifier as **Account ID** field. Account identifier is the part before `.snowflakecomputing.com` in your snowflake host URL:

<p align="center">
   <img width="70%" alt="Account Id Field" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_account_id.png"/>
</p>

_Learn more about Snowflake Account Identifiers [here](https://docs.snowflake.com/en/user-guide/admin-account-identifier.html#account-identifiers)_

Set the authentication mode to key-pair and reference the secret you just created:

- Set **Authentication Type** to **Private Key** (`KEY_PAIR_AUTHENTICATOR`)
- In the **Private Key** field, select the `SNOWFLAKE_PRIVATE_KEY` secret
- If your private key is passphrase-protected, select the `SNOWFLAKE_PRIVATE_KEY_PASSWORD` secret in the **Private Key Password** field

Selecting **Private Key** reveals the **Private Key** and **Private Key Password** fields and hides the **Password** field. The resulting recipe keys are:

```yaml
source:
  type: snowflake
  config:
    account_id: "abc48144"
    username: "${SNOWFLAKE_USER}"
    authentication_type: KEY_PAIR_AUTHENTICATOR
    private_key: "${SNOWFLAKE_PRIVATE_KEY}"
    # Required only if the private key is passphrase-protected:
    # private_key_password: "${SNOWFLAKE_PRIVATE_KEY_PASSWORD}"
    role: "datahub_role"
    warehouse: "COMPUTE_WH"
```

:::note Editing the YAML directly?
The form fields map to the `authentication_type`, `private_key`, and `private_key_password` recipe keys. See the [key-pair migration guide](migrate-to-key-pair-auth.md#step-2--datahub-side-update-the-recipe) for the exact YAML.
:::

Populate the relevant fields using the same **Username**, **Role**, and **Warehouse** you created and/or specified in [Snowflake Prerequisites](setup.md).

<p align="center">
   <img width="70%" alt="Warehouse Field" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_warehouse_username_role_fields.png"/>
</p>

7. Click **Test Connection**

This step will ensure you have configured your credentials accurately and confirm you have the required permissions to extract all relevant metadata.

<p align="center">
  <img width="75%" alt="Test Snoflake connection" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_test_connection.png"/>
</p>

After you have successfully tested your connection, click **Next**.

## Schedule Execution

Now it's time to schedule a recurring ingestion pipeline to regularly extract metadata from your Snowflake instance.

8. Decide how regularly you want this ingestion to run-- day, month, year, hour, minute, etc. Select from the dropdown

<p align="center">
    <img width="75%" alt="schedule selector" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_set_execution_schedule.png"/>
</p>

9. Ensure you've configured your correct timezone
<p align="center">
    <img width="75%" alt="timezone_selector" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_set_execution_timezone.png"/>
</p>

10. Click **Next** when you are done

## Finish Up

11. Name your ingestion source, then click **Save and Run**
<p align="center">
  <img width="75%" alt="Name your ingestion" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/common/common_ingestion_name_ingestion_source.png"/>
</p>

You will now find your new ingestion source running

<p align="center">
  <img width="75%" alt="ingestion_running" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_source_running.png"/>
</p>

## Validate Ingestion Runs

12. View the latest status of ingestion runs on the Ingestion page

<p align="center">
  <img width="75%" alt="ingestion succeeded" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_ingestion_succeded.png"/>
</p>

13. Click the plus sign to expand the full list of historical runs and outcomes; click **Details** to see the outcomes of a specific run

<p align="center">
  <img width="75%" alt="ingestion_details" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_ingestion_details.png"/>
</p>

14. From the Ingestion Run Details page, pick **View All** to see which entities were ingested

<p align="center">
  <img width="75%" alt="ingestion_details_view_all" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_details_view_all.png"/>
</p>

15. Pick an entity from the list to manually validate if it contains the detail you expected

<p align="center">
  <img width="75%" alt="ingestion_details_view_all" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/guides/snowflake/snowflake_ingestion_view_ingested_assets.png"/>
</p>

**Congratulations!** You've successfully set up Snowflake as an ingestion source for DataHub!

## Advanced Configuration

### Snowflake Internal Marketplace (Optional)

If you want to ingest Snowflake internal marketplace listings (private data sharing via Data Exchange) as Data Products, you'll need to enable additional configuration.

#### For Consumer Organizations (Purchasing Listings)

If you purchase/install internal marketplace listings, add these options to your recipe:

```yaml
marketplace:
  enabled: true
  marketplace_mode: "consumer" # This is the default
  # Optional: Configure time window for usage statistics
  start_time: "-7 days" # Default: -1 day
  end_time: "now"

# Required: Map your imported databases to their source shares
shares:
  DEMO_DATABASE_SNOWFLAKE_SHARE_1754064671731: # From: SHOW SHARES
    database: "SOURCE_DATABASE" # Source database in the share
    consumers:
      - database: "DEMO_DATABASE" # Your purchased/imported database
        # Optional but recommended: Explicit listing mapping for precise linking
        listing_global_name: "PROVIDER.REGION.LISTING_NAME" # From: SHOW AVAILABLE LISTINGS
```

**Tip**: Adding `listing_global_name` ensures your purchased databases are accurately linked to their marketplace listings, especially when you have multiple similar listing names.

#### For Provider Organizations (Publishing Listings)

If you publish/share data through the internal marketplace, add these options to your recipe:

```yaml
marketplace:
  enabled: true
  marketplace_mode: "provider"
  # Optional: Assign owners to your Data Products
  internal_marketplace_owner_patterns:
    "^Customer.*": ["data-team"]
  # Optional: Configure time window for usage statistics
  start_time: "-30 days"
  end_time: "now"

# Include your source databases being shared
database_pattern:
  allow:
    - "YOUR_SOURCE_DATABASE"
```

**Important**: For provider mode to work, you must have granted `imported privileges on database snowflake` to both the role AND the user (see [Setup](setup.md) for details). Share access in Snowflake is granted at the user level, not the role level.

#### For Organizations Doing Both

Use `marketplace_mode: "both"` to track both purchased and published listings in the same ingestion.

For complete documentation on marketplace configuration, see the [Snowflake connector documentation](https://datahub.io/docs/generated/ingestion/sources/snowflake).
