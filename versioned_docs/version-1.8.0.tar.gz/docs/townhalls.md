---
title: DataHub Town Halls
sidebar_label: Town Halls
slug: /townhalls
custom_edit_url: 'https://github.com/datahub-project/datahub/blob/master/docs/townhalls.md'
---
# DataHub Town Halls

Join us for community gatherings where we discuss roadmap updates, demo new features, and hear from DataHub users around the world.

## 🗓️ Next Town Hall

Town Halls run monthly. [Register on our events calendar →](https://luma.com/datahubevents?tag=datahub%20town%20hall)

---

## 📺 Recent Town Halls

**July 2026: Real Stories in Production feat. Miro & Just Eat Takeaway**

- 📺 [Watch recording](https://youtu.be/B5cV9ZPgg30)

**June 2026: Inside the Context Platform feat. TiDB / PingCAP**

- 📺 [Watch recording](https://www.youtube.com/watch?v=JboXwGIz54k)

**May 2026: Context to Action with Grab, dltHub, and iFood**

- 📺 [Watch recording](https://youtu.be/GsnX7edN6Rw)

**April 2026: Talk to Data – The Context Edition feat. Pinterest, Omni and DataHub**

- 📺 [Watch recording](https://youtu.be/qqFUewpnGYg)

**March 2026: Agents, Apps & the Art of Extension**

- 📺 [Watch recording](https://www.youtube.com/watch?v=MAyldt2n3R8)

**February 2026: Lineage in Action: Extending Reach, Enriching Context**

- 📺 [Watch recording](https://www.youtube.com/watch?v=vXJd2ho0i-o)

**January 2026: Powering AI Agents with DataHub Context**

- 📺 [Watch recording](https://youtu.be/dqZNV09yvA0)

**December 2025: Building AI Agents You'd Trust in Production**

- 📺 [Watch recording](https://www.youtube.com/watch?v=oWiT7tkSZgo)

**[→ View all Town Hall recordings](https://www.youtube.com/playlist?list=PLdCtLs64vZvHTXGqybmOfyxXbGDn2Reb9)**

---

## 💡 What We Typically Cover

- **Product Roadmap Updates** - What's coming next in DataHub
- **Feature Demos** - Live walkthroughs of new capabilities
- **Community Case Studies** - How teams are using DataHub in production
- **Open Q&A** - Ask the team anything

## 🙋 Want to Participate?

- **Ask Questions:** Submit topics via [Slack #townhall channel](https://datahub.com/slack)
- **Share Your Story:** Using DataHub at your company? We'd love to feature you - reach out in Slack
- **Suggest Topics:** Drop ideas in the #townhall channel

---

## 📅 Upcoming Community Events

Check out our DataHub Community Calendar to RSVP to office hours and upcoming events!

<p align="center">
  <iframe
    src="https://lu.ma/embed/calendar/cal-lom9HnTVnZkKsNh/events"
    width="80%"
    height="450"
    frameborder="0"
    allowfullscreen=""
    aria-hidden="false"
    tabindex="0"
  ></iframe>
</p>
