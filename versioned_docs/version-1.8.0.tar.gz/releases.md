---
title: DataHub Releases
sidebar_label: Releases
slug: /releases
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs-website/generateDocsDir.ts
---

# DataHub Releases

## Summary

| Version | Release Date | Links |
| ------- | ------------ | ----- |
| **v1.9.0** | 2026-11-16 |[Release Notes](#v1-9-0), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.9.0) |
| **v1.6.0.5** | 2026-11-12 |[Release Notes](#v1-6-0-5), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.5) |
| **v1.6.0.4** | 2026-10-29 |[Release Notes](#v1-6-0-4), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.4) |
| **v1.8.0** | 2026-10-12 |[Release Notes](#v1-8-0), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.8.0) |
| **v1.6.0.3** | 2026-09-25 |[Release Notes](#v1-6-0-3), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.3) |
| **v1.7.0.1** | 2026-09-03 |[Release Notes](#v1-7-0-1), [View on GitHub](https://github.com/datahub-project/datahub/releases/tag/v1.7.0.1) |


## [v1.9.0](https://github.com/datahub-project/datahub/releases/tag/v1.9.0) {#v1-9-0}

Released on 2026-11-16 by [@datahub-release-bot[bot]](https://github.com/apps/datahub-release-bot).

### v1.9.0

#### Release Availability Date

16 Nov 2026

#### Requirements

- **CLI / Python SDK:** 1.7.0.19
- **Helm chart:** 1.1.10

Upgrade actions are in [Breaking Changes for v1.9.0](https://docs.datahub.com/docs/how/breaking-changes#v190).

#### Highlights

- **Metrics are on by default.** `METRICS_ENABLED` now defaults to `true`, which turns on the Metrics page, the `/metrics` route, and the backend wiring for Metric and Semantic Model. v1.8.0 defaulted to `false`. Set `METRICS_ENABLED=false` to turn it off.
- **Google Drive source (Alpha).** Ingests Google Docs from chosen folders and shared drives as Document entities, so they are searchable, including with semantic search.
- **`datahub recipe probe`.** Checks what a recipe would ingest before a run. `probe`, `test-connection`, and `validate` now use exit code 2 for bad input, 3 for a source failure, and 1 for DataHub, the connector, or a missing package.
- **Elasticsearch 7.x is no longer supported.** Use Elasticsearch 8.x, or OpenSearch 2.x or 3.x.
- **System client credentials go only to the configured server.** A client created without a token sends `DATAHUB_SYSTEM_CLIENT_ID` and `DATAHUB_SYSTEM_CLIENT_SECRET` only to the server in `DATAHUB_GMS_URL`. UI-managed ingestion refuses recipes that would send them elsewhere.

#### Product

- Child Applications appear in the parent Application's Assets tab. ([[#20420](https://github.com/datahub-project/datahub/pull/20420)](https://github.com/datahub-project/datahub/pull/20420))
- Group search ranks results by relevance instead of creation time. ([[#21073](https://github.com/datahub-project/datahub/pull/21073)](https://github.com/datahub-project/datahub/pull/21073))
- The schema filter menu and the default Navigate sidebar were fixed. ([[#21150](https://github.com/datahub-project/datahub/pull/21150)](https://github.com/datahub-project/datahub/pull/21150))
- A button label stays visible in Firefox after loading ends. ([[#21073](https://github.com/datahub-project/datahub/pull/21073)](https://github.com/datahub-project/datahub/pull/21073))

#### Platform

- Assertion status comes from the latest run across results. ([[#20954](https://github.com/datahub-project/datahub/pull/20954)](https://github.com/datahub-project/datahub/pull/20954))
- A race condition in reindexing is fixed. ([[#21073](https://github.com/datahub-project/datahub/pull/21073)](https://github.com/datahub-project/datahub/pull/21073))
- Concurrent sign-up or password reset no longer shares one hash digest across threads, so a corrupt password hash cannot be stored. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- Batch tag and glossary term writes keep every column's change, not just the last one. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- An aspect left unchanged by a write hook keeps its stored version and does not add a history row. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- `datahub-upgrade -u Cleanup` and `-u LoadIndices` start again. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- When the token store cannot be read, GMS returns **503** with `Retry-After` instead of **401**. The delay is set by `AUTH_UNAVAILABLE_RETRY_AFTER_SECONDS` (default 3) plus up to `AUTH_UNAVAILABLE_RETRY_AFTER_JITTER_PERCENT` (default 50) percent. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- With separate producer and consumer Kafka settings, the admin client uses the producer security protocol and applies the MSK IAM configuration. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))
- Sliced scroll reuses the point-in-time across pages, and cached search handlers are isolated by field metadata. ([[#21256](https://github.com/datahub-project/datahub/pull/21256)](https://github.com/datahub-project/datahub/pull/21256))

#### Ingestion

- The UI-managed ingestion executor validates `extra_pip_requirements` before it installs them. ([[#21203](https://github.com/datahub-project/datahub/pull/21203)](https://github.com/datahub-project/datahub/pull/21203))
- The ingestion framework runs on SQLAlchemy 2.0. `acryl-datahub` requires `click>=8.3.3` and `anyio>=4.14.2`.
- DataHub Lite uses SQLite for new instances. DuckDB is a separate extra.
- The `hive` and `presto` sources no longer use PyHive.

#### Security

- **Apache ZooKeeper 3.8.8.** Fixes CVE-2026-100252, CVE-2026-100300, CVE-2026-100302, CVE-2026-115448, and CVE-2026-100235. It is a patch release on the 3.8 line, so the API is unchanged. ([[#21258](https://github.com/datahub-project/datahub/pull/21258)](https://github.com/datahub-project/datahub/pull/21258))
- **Apache Thrift (libthrift) 0.24.0** for CVE-2026-48586. ([[#19932](https://github.com/datahub-project/datahub/pull/19932)](https://github.com/datahub-project/datahub/pull/19932))
- **lz4-java 1.11.4** for CVE-2026-106451. ([[#20298](https://github.com/datahub-project/datahub/pull/20298)](https://github.com/datahub-project/datahub/pull/20298))
- **Node.js 22.23.4.** ([[#20605](https://github.com/datahub-project/datahub/pull/20605)](https://github.com/datahub-project/datahub/pull/20605))
- **org.json 20260814** for CVE-2026-59171. ([[#21201](https://github.com/datahub-project/datahub/pull/21201)](https://github.com/datahub-project/datahub/pull/21201), via [[#21203](https://github.com/datahub-project/datahub/pull/21203)](https://github.com/datahub-project/datahub/pull/21203))
- **netty-tcnative 2.0.84** and **filelock 4.2.1**. ([[#21174](https://github.com/datahub-project/datahub/pull/21174)](https://github.com/datahub-project/datahub/pull/21174), via [[#21203](https://github.com/datahub-project/datahub/pull/21203)](https://github.com/datahub-project/datahub/pull/21203))
- **Bouncy Castle (jdk18on) 1.86.** ([[#19924](https://github.com/datahub-project/datahub/pull/19924)](https://github.com/datahub-project/datahub/pull/19924))
- **JLine 4.3.1.**
- **Python floors:** `deepdiff` and `click` ([[#19928](https://github.com/datahub-project/datahub/pull/19928)](https://github.com/datahub-project/datahub/pull/19928)), `anyio>=4.14.2` and `soupsieve>=2.9.0` ([[#19925](https://github.com/datahub-project/datahub/pull/19925)](https://github.com/datahub-project/datahub/pull/19925)), `pyasn1` 0.6.5 ([[#20845](https://github.com/datahub-project/datahub/pull/20845)](https://github.com/datahub-project/datahub/pull/20845)), and `setuptools` 84.1.0.
- **Java dependencies:** netty, Vert.x, reactor-netty, Guava, snappy-java, and protobuf were bumped. ([[#20954](https://github.com/datahub-project/datahub/pull/20954)](https://github.com/datahub-project/datahub/pull/20954))
- **Hazelcast** deserializes only allow-listed classes from its peers. See Breaking Changes.
- **DataHub Documents** no longer parses Markdown link and image syntax, which closes a denial-of-service path in Python-Markdown (CVE-2019-25781). See Breaking Changes.

#### Deprecations

- Audit stamps that only repeat the DataHub write are deprecated in favor of `systemMetadata.aspectCreated` and `systemMetadata.aspectModified`. The old fields remain and are still indexed.
- `GET /admin` and `GET /health` on the Play port (9002) are deprecated as health checks. They still return `200 GOOD`, or `503` during graceful shutdown.

#### Breaking Changes

The full list, with actions, is in [Breaking Changes for v1.9.0](https://docs.datahub.com/docs/how/breaking-changes#v190). The main changes are:

- **Authorization.** Changing an entity's platform instance or domain is checked against both the old and the new value. Assertion APIs apply the same asset-level permissions as the UI. Scheduling an ingestion source requires permission. Invite tokens that assign a role require **Manage User Credentials** and **Manage Policies**. Privilege-constraint denials on tags and structured properties return **403** instead of **400**.
- **Search.** Elasticsearch 7.x is removed. Search V3 keyword scoring, default query fields, indexed fields, and the lineage and browse templates changed. Timeseries indices refresh every 60 seconds by default.
- **Hard rollback.** The UI Rollback button and `datahub ingest rollback --nuke` no longer delete an entity once another run or a user has written to it.
- **Conditional writes.** `If-Version-Match` and `If-Modified-Since` apply to generic JSON patches.
- **Ingestion.** Airflow plugin datasets use the same URNs as the S3, GCS, and Azure Blob sources, so lineage recorded under old URNs stays on the old datasets. dbt `manifest_path` treats `*`, `?`, `[`, and `]` as glob characters, and semantic models are no longer modeled as warehouse tables. Sigma runs fail when an entity listing fails. The profiling config classes lost their `GE` prefix.
- **CLI.** `datahub recipe` commands return the exit codes above. The `cloud` pip extra was removed from `acryl-datahub`.
- **Logging and startup.** GMS no longer writes DEBUG logs to `gms.debug.log` by default. GMS, MAE, and MCE no longer wait on the `DataHubUpgradeHistory_v1` marker.

**Full Changelog**: https://github.com/datahub-project/datahub/compare/v1.8.0...v1.9.0


## [v1.6.0.5](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.5) {#v1-6-0-5}

Released on 2026-11-12 by [@supersingh05](https://github.com/supersingh05).

### DataHub v1.6.0.5

Patch release for the **v1.6.0 LTS** line. Focus is security: November CVE dependency bumps, Jackson 2.22.4, and hardening of the `datahub-documents` source, which now also works without outbound network access.

**Full diff:** https://github.com/datahub-project/datahub/compare/v1.6.0.4...v1.6.0.5

---

#### Operator notes

- **`datahub-documents` no longer parses Markdown links or images, and partitioning has a CPU-time limit.** Link and image syntax is kept as literal text, which removes the quadratic parsing path behind CVE-2019-25781. Partitioning one document stops after `partition_timeout_seconds` (default 30 s) ([#21204](https://github.com/datahub-project/datahub/pull/21204), from [#21125](https://github.com/datahub-project/datahub/pull/21125)).
  - A document that hits the limit is skipped with a warning and counted in `num_documents_partition_timeout`. Its hash is still recorded, so it is not retried until its content changes. Embeddings written by an earlier version are left in place.
- **The spaCy model `en_core_web_sm` is now bundled in the images.** `unstructured` loads this model the first time it partitions text. Earlier v1.6.0 images did not include it, so `datahub-documents` (and other `unstructured`-based sources) downloaded it from github.com on first use. Without outbound access, each document failed after a 120 s timeout with `Failed to download spaCy model`, and the run still reported success with 0 chunks. The model is now installed in the bundled ingestion venvs of the `datahub-actions` images and in the full `datahub-ingestion` image ([#21210](https://github.com/datahub-project/datahub/pull/21210), from [#19554](https://github.com/datahub-project/datahub/pull/19554)).
  - **Documents that failed this way on v1.6.0.4 or earlier are not re-processed automatically.** Their hashes were recorded, so they are skipped as unchanged until their content changes. Edit those documents, or reset the source's state, to have them chunked.
  - Loading the model raises the memory used by `datahub-documents` runs. The Helm chart's default `acryl-datahub-actions` memory limit (512Mi) leaves little headroom, so consider raising it if you use Documents, especially if runs can overlap.
- **Fresh installs of `acryl-datahub` work again.** `sqlglot[c]` is pinned to **30.11.0**. PyPI no longer serves `sqlglotc` wheels for 30.7.0–30.10.0, so with the previous 30.8.0 pin every fresh install of this line tried to build `sqlglotc` from source and failed ([#21204](https://github.com/datahub-project/datahub/pull/21204)).

---

#### Security

| Area | Fix |
| --- | --- |
| Jackson | **2.22.4**: jackson-dataformat-smile CVE-2026-104895 (GHSA-h3c2-2m49-r49w, unbounded allocation in the async parser) and jackson-dataformat-cbor CVE-2026-106554 (GHSA-cjg7-h3pr-p927) ([#21208](https://github.com/datahub-project/datahub/pull/21208)) |
| Java runtime libraries | org.json **20260814** (CVE-2026-59171), netty-tcnative **2.0.84.Final** (CVE-2026-116541), json-smart / accessors-smart **2.6.1** (CVE-2026-113602) ([#21204](https://github.com/datahub-project/datahub/pull/21204)) |
| unstructured / filelock | unstructured **0.27.37** lifts the `filelock&lt;4` cap; filelock **4.2.10** (CVE-2026-112940); snowflake-connector-python resolves to 4.8.1 ([#21204](https://github.com/datahub-project/datahub/pull/21204)) |
| Other Python | pyasn1 **≥0.6.5** (CVE-2026-119194 / 119195 / 119196 / 119197), markdown **≥3.11.3** ([#21204](https://github.com/datahub-project/datahub/pull/21204)) |

**markdown 3.11.3 does not fix CVE-2019-25781 by itself.** Advisories list 3.0–3.11.2 as affected, so the floor clears scanners, but 3.11.3 still parses unclosed brackets in quadratic time. The `datahub-documents` change in the operator notes is the actual fix.

**Not included:**
- Jackson 2.21.2 / 3.1.2 and org.json 20250107 shaded inside `hazelcast-5.7.0.jar`. 5.7.0 is the latest Hazelcast OSS release.
- Guava CVE-2026-102554 in the copies shaded into graphql-java and Iceberg. The standalone guava is 33.7.2. Since v1.6.0.4, the embedded Hazelcast rejects Guava classes during deserialization.
- json-smart 1.3.2 and older Hadoop / Hive jars in the `datahub-actions` full image. They come from the bundled PySpark venv; the slim and locked images do not include it.

---

**Full Changelog:** https://github.com/datahub-project/datahub/compare/v1.6.0.4...v1.6.0.5


## [v1.6.0.4](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.4) {#v1-6-0-4}

Released on 2026-10-29 by [@supersingh05](https://github.com/supersingh05).

### DataHub v1.6.0.4

Patch release for the **v1.6.0 LTS** line. Focus is security: October CVE dependency bumps, an allow-list for Java deserialization in GMS's embedded Hazelcast, and tighter handling of system client credentials in the Python client.

**Full diff:** https://github.com/datahub-project/datahub/compare/v1.6.0.3...v1.6.0.4

---

#### Operator notes

- **Embedded Hazelcast only deserializes allow-listed classes from its peers.** Allowed: JDK types, `com.hazelcast.*`, `com.linkedin.metadata.*` and `org.javatuples.*` (search cache keys). Guava classes, including the copies bundled in graphql-java and Iceberg, are always rejected. Before, any process that could reach the cluster port (5701 by default) could trigger `readObject` on any `Serializable` class on the GMS classpath ([#20783](https://github.com/datahub-project/datahub/pull/20783), from [#20776](https://github.com/datahub-project/datahub/pull/20776)).
  - **No action needed for a standard deployment.** During a rolling upgrade from an older version, an upgraded GMS may not be able to read search cache keys that older pods wrote. Eviction skips those keys with a warning, and they expire with the cache TTL (`CACHE_TTL_SECONDS`, 10 minutes by default).
  - If an extension stores its own `Serializable` types in Hazelcast, allow them with `SEARCH_SERVICE_HAZELCAST_SERIALIZATION_ALLOWED_CLASSES` or `SEARCH_SERVICE_HAZELCAST_SERIALIZATION_ALLOWED_PACKAGE_PREFIXES` (comma-separated), or register a `HazelcastSerializationAllowListContributor` bean. Rejected types fail with `HazelcastSerializationException` ("Resolving class ... is not allowed").
- **Breaking (Python client): system client credentials are only sent to the configured GMS.** A client created without a token (REST emitter, `DataHubGraph`, `datahub-rest` sink) now attaches `DATAHUB_SYSTEM_CLIENT_ID` / `DATAHUB_SYSTEM_CLIENT_SECRET` only when its server matches `DATAHUB_GMS_URL` (or `DATAHUB_GMS_HOST` / `DATAHUB_GMS_PORT` / `DATAHUB_GMS_PROTOCOL`). Otherwise it connects without credentials and logs a warning. Hosts are compared as written, so `http://localhost:8080` and `http://127.0.0.1:8080` do not match ([#20783](https://github.com/datahub-project/datahub/pull/20783), from [#20717](https://github.com/datahub-project/datahub/pull/20717)).
- **Breaking (Python SDK): the `cloud` pip extra is removed.** `pip install 'acryl-datahub[cloud]'` no longer installs the cloud package; pip only warns about the missing extra. Install `acryl-datahub-cloud` directly; it pins the matching `acryl-datahub` ([#20676](https://github.com/datahub-project/datahub/pull/20676), from [#20325](https://github.com/datahub-project/datahub/pull/20325)).
- **Default managed-ingestion CLI version is now 1.7.0.17**, so UI-triggered ingestion installs a CLI that includes the dependency fixes below ([#20676](https://github.com/datahub-project/datahub/pull/20676)).

---

#### Security

| Area | Fix |
| --- | --- |
| Frontend SSO | pac4j **6.5.8**, play-pac4j **13.0.3** (CVE-2026-82461 / 82462 / 82463 / 82464 / 82465); brings nimbus-jose-jwt 10.9.1, oauth2-oidc-sdk 11.38.2, json-smart 2.6.0 |
| Java runtime libraries | netty **4.2.19**, vert.x **4.5.35**, reactor-netty **1.3.8**, guava **33.7.2**, snappy-java **1.1.10.12**, protobuf **4.36.2**, hadoop **3.4.2** (brings avro 1.11.4), google-api-client **2.9.2**, lz4-java **1.11.4** (CVE-2026-106451) |
| starlette / fastapi | starlette **≥1.3.1** (CVE-2026-48710 / 48817 / 48818 / 54282 / 54283), fastapi **≥0.133** |
| aiohttp and friends | aiohttp **≥3.14.4** (CVE-2026-111064), multidict **≥6.9.1** (CVE-2026-104874), mako **≥1.4.2** (CVE-2026-102991), fsspec **≥2026.6.0** (CVE-2026-104851) |
| Auth libraries | authlib **≥1.9.0** (CVE-2026-96760), joserfc **≥1.7.4** (CVE-2026-102946), PyJWT **≥2.15.0** |
| pip / certifi / setuptools | pip **≥26.2.2** and certifi **≥2026.10.19** (GHSA-6q48-6c7w-9gw2), setuptools **≥84.1.0** (GHSA-xmj3-9gf7-h52w) |
| Other Python | pypdf **≥6.19.0** (CVE-2026-103000), snowflake-sqlalchemy **≥1.11.0** (CVE-2026-15736), opentelemetry-api **≥1.45.1** (CVE-2026-114603), urllib3 **≥2.8.0** |
| Node.js | **22.23.4** (October 2026 security release) |
| Images | CA trust store refresh and Python floors in the Docker ingestion constraints |

**Not included:** oauthlib 4.0.0 (CVE-2026-49264 / 49265). This line uses databricks-sql-connector 2.9.6, which caps oauthlib below 4; oauthlib stays at 3.3.1.

---

#### Fixes and CI

- The backported `semanticText` document tests now match the v1.6.0 source, so `ci (3.11/3.12, testQuick)` passes on this branch again ([#20676](https://github.com/datahub-project/datahub/pull/20676)).
- pytest capped below 10 in the Airflow and Prefect plugin setups; Grafana and Prometheus images pinned in the Grafana integration test ([#20783](https://github.com/datahub-project/datahub/pull/20783)).

---

**Full Changelog:** https://github.com/datahub-project/datahub/compare/v1.6.0.3...v1.6.0.4


## [v1.8.0](https://github.com/datahub-project/datahub/releases/tag/v1.8.0) {#v1-8-0}

Released on 2026-10-12 by [@datahub-release-bot[bot]](https://github.com/apps/datahub-release-bot).

### v1.8.0

#### Release Availability Date

22 Oct 2026

#### Requirements

- **CLI / Python SDK:** 1.7.0.14
- **Helm chart:** 1.1.8

Upgrade actions are in [Updating DataHub](https://docs.datahub.com/docs/how/updating-datahub#v180).

#### Highlights

- **OpenSearch 3.x.** Supported next to OpenSearch 2.x and Elasticsearch 8.x. The engine version is detected automatically. OpenSearch 3.x will not create new indexes with the `nmslib` kNN engine, and it enforces the 512-byte document-id limit on bulk writes.
- **Metrics and Semantic Models.** Charts, dashboards, and datasets can take a Metric as an upstream, with column-level lineage through metric upstreams. Metrics and Semantic Models are included in global search. The feature ships **off**. Set `METRICS_ENABLED=true` on GMS to show it.
- **Dark mode.** A dark theme is in this release and stays **off** until `THEME_DARK_MODE_ENABLED=true`. With that set, the toggle is under **Settings → Appearance**.
- **Structured Properties.** Creating, editing, and viewing a structured property is a page rather than a side drawer. Allowed values can be reordered, each with an optional description. Leaving the page with unsaved edits prompts before discarding them. The properties table adds **Type** and **Platforms** columns.
- **Data Products.** Data Products can nest under a parent Data Product. Data Products are filterable in global search. On upgrade, a one-time system update fills the asset-side `dataProducts` search field from stored membership so that filter matches existing members. It is on by default (`BOOTSTRAP_SYSTEM_UPDATE_DATA_PRODUCT_ASSETS_ENABLED=true`).
- **New ingestion sources.** [IBM/HCL Informix](https://docs.datahub.com/docs/generated/ingestion/sources/informix), [Monte Carlo](https://docs.datahub.com/docs/generated/ingestion/sources/montecarlo), and SQLMesh.

#### Product

- **Compliance forms** can be assigned to owners of a specific ownership type.
- **Deprecation date** input is editable.
- **Languages in public beta:** Japanese, Simplified Chinese, Traditional Chinese, and Russian.
- **Sidebars.** Domains, glossary, metrics, and documents sidebars can sort and filter. The home page Domains module lists up to 25 domains.
- **Views** can filter on structured properties.
- **Incidents** can be raised on ML models, ML features, ML feature tables, and schema fields.

#### Platform

- **Search document ids (Search V3).** Search V3 documents use a SHA-256 of the entity URN as `_id`. V2 indexes are unchanged. If an environment already wrote V3 documents under URL-encoded ids, hashed ids are not an in-place rewrite. Run RestoreIndices with `-a clean`, or reindex into a fresh index. A fill without clean leaves the old `_id` in place and the next update creates a duplicate.
- **GraphQL worker pool.** When `GRAPHQL_CONCURRENCY_SEPARATE_THREAD_POOL=true`, pool sizes no longer follow the node’s CPU count. Defaults are the 8-core sizes: core 40, max 800. The separate pool stays off by default.
- **AWS IRSA.** GMS keeps one process-wide default credentials provider, built once and closed on shutdown.
- **Timeseries reads.** Dataset profile, usage, and operations, and dashboard usage statistics, require the matching View privileges on Rest.li and OpenAPI as well as GraphQL.
- **Access tokens.** Creating a token with no expiry is disabled. Allowed durations default to 1 hour, 1 day, 7 days, 30 days, 90 days, 180 days, and 365 days. Tokens that already exist, including never-expiring ones, keep working.
- **Query SQL.** Reading a query, a view definition, or `topSqlQueries` requires **View Entity Queries** on a subject dataset, or the platform privilege **View All Queries**. On upgrade, policies that already grant View Entity Page are backfilled with both. A policy created after the upgrade that only grants View Entity Page does not reveal query SQL.

#### Ingestion

**New sources:** IBM/HCL Informix, Monte Carlo, SQLMesh.

**Connectors:**

- **Snowflake.** Logical tables in semantic views keep their stored casing. `preserve_column_case` keeps Snowflake’s column casing in field paths and column-level lineage. It is off by default. Turning it on changes every column’s `schemaField` URN.
- **BigQuery.** Sharing linked datasets, multi-column partition info, and dataset profiles for materialized views. The profiler lives in its own package.
- **Cube.** Cube views are ingested as Semantic Models. `emit_semantic_model_entities: true` emits first-class semantic model, metric, and semantic-model dataset entities. That path needs `METRICS_ENABLED=true`.
- **Dataplex.** Metadata Export API extraction.
- **Metabase.** Column-level lineage, model ingestion, and collection tags and containers.
- **MicroStrategy.** Project schema can be ingested as a Semantic Model.
- **Power BI.** Lineage for BigQuery `EXTERNAL_QUERY`.
- **SAP Analytics Cloud.** Column-level lineage to SAP Datasphere for DWC live models, and SAC to SAP Datasphere live-model lineage.
- **SAP Datasphere.** Calculated column formulas are written into the column description.
- **Sigma.** Dataset lineage is recovered from Sigma’s connection metadata. See Breaking Changes.
- **Kafka Connect.** SQL Server is a three-level platform. See Breaking Changes.
- **Looker.** Per-field explore usage from System Activity.
- **Airbyte.** Inactive connections can be ingested by opting in. Doris can ingest Iceberg tables in non-default catalogs.

**Ingestion infrastructure:**

- Connector support tiers are **Alpha**, **Beta**, and **GA**. The old names Certified, Incubating, and Testing are removed.
- SQL lineage timeout is configurable.
- Structured property settings can be ingested from the Python SDK.
- Stdin envelope secrets are registered for masking when they arrive.
- `confluent-kafka` is 2.15.1. A custom `oauth_cb` must return an absolute expiry time, not a lifetime in seconds.

#### Breaking Changes

Full actions are in [Updating DataHub](https://docs.datahub.com/docs/how/updating-datahub#v180).

- **Sigma ingestion.** Sigma Dataset lineage URNs are built from `connection_to_platform_map` rather than `chart_sources_platform_mapping`. Add the Sigma `connectionId` to that map with the `env` and `platform_instance` your warehouse connector used. Set `convert_urns_to_lowercase: true` if you want the previous spelling for those table names.
- **Structured property hard-delete.** An active structured property cannot be hard-deleted, and its `propertyDefinition` aspect cannot be deleted directly, until the property is soft-deleted. The UI does both steps. Automation that issued one hard delete must soft-delete, then hard-delete.
- **Timeseries read authorization.** API clients that read dataset profile, usage, or operations with only entity GET need **View Dataset Profile**, **View Dataset Usage**, or **View Dataset Operations**. Dedicated timeseries APIs also require **Get Timeseries Aspect API** when REST API authorization is enabled.
- **Role and group membership.** Adding a role (`roleMembership`) requires **Manage Policies**. Adding a group member requires **Edit Group Members**. Adding a group owner requires **Edit Owners**. When the acting user is the one being added, both require **Manage Users & Groups**. **Edit Entity** on a user is no longer enough to grant that user Admin.
- **Analytics API.** `POST /openapi/v2/analytics/datahub_usage_events/_search` requires **Analytics API access** or **Manage System Operations**. The in-app analytics dashboard still uses **View Analytics**.
- **Compliance form assignment.** `batchAssignForm`, `batchRemoveForm`, `createDynamicFormAssignment`, and writes that change which forms are on an asset, require **Manage Compliance Forms**. Completing an assigned form is unchanged.
- **Asset summary settings.** `updateAssetSettings` and writes to `assetSettings` require **Edit Entity** or **Manage Asset Summary** on the asset. OpenAPI and Rest.li still treat the write as a generic entity update, so **Manage Asset Summary** alone is not enough there.
- **Never-expiring access tokens.** Disabled unless `ACCESS_TOKEN_ALLOW_NO_EXPIRY=true`. Set `ACCESS_TOKEN_ALLOWED_DURATIONS` to change the allowed TTLs.
- **OpenAPI create is per URN.** A principal with only **Create Entity** cannot overwrite an existing entity through create or UPSERT. Grant **Edit Entity** to callers that update existing entities.
- **Domain-scoped create.** Domain-scoped Create and Edit policies are evaluated against the domains proposed on a new entity. A `domains` PATCH requires **Edit Entity**, and domain-scoped Edit must allow both the previous and the new domain membership.
- **Group member removal.** `removeGroupMembers` removes members who only have the legacy `groupMembership` aspect.
- **Documents.** The default Editor role no longer has **Manage Documents**. Editors can create, edit, and move documents, and can delete documents they own.
- **Password hashes.** Reading `corpUserCredentials` requires **Manage User Credentials**.
- **Kafka Connect.** SQL Server sink URNs gain a `dbo` schema when `schema.name` is unset (`database.table` becomes `database.dbo.table`). A SQL Server source dataset with no resolvable schema is dropped with a warning. Oracle JDBC sinks emit `schema.table`.
- **Elasticsearch ingestion.** `acryl-datahub[elasticsearch]` requires `opensearch-py` 3.x. The 3.x client still talks to OpenSearch 2 clusters.
- **Great Expectations SQL profiler.** Removed. The SQLAlchemy profiler is the only SQL profiler. `profiling.method` and the `acryl-datahub[profiling-ge]` extra are gone. This does not affect the Great Expectations integration that ingests GX validation results.
- **MySQL, MariaDB, Doris, and TiDB profiling limits.** `profiling.profile_table_row_limit` and `profiling.profile_table_size_limit` are enforced. They were previously accepted and ignored. Both still default to unset on these sources.
- **`sql-queries`.** A run where every input line is unparseable, or every query fails, exits non-zero. `enable_lazy_schema_loading` is removed. Report fields `num_queries_processed_sequential` and `num_temp_tables_detected` are renamed.
- **Python SDK circuit breakers.** `Assertion` and `Operation` clients take `graph=` instead of `transport=`. GraphQL errors raise `GraphError`.
- **Connector support status names.** `SupportStatus.CERTIFIED`, `INCUBATING`, and `TESTING` are removed. Use `GA`, `BETA`, and `ALPHA`.
- **Python extras.** `notion`, `confluence`, `unstructured`, and `datahub-documents` require Python 3.11+ and are no longer installed by `acryl-datahub[all]`.
- **Kafka OAuth callbacks.** Since `confluent-kafka` 2.13, the second value returned by `oauth_cb` is an absolute expiry in epoch seconds. A callback that returns a lifetime such as `3600` now looks already expired.
- **Search indexing startup.** GMS refuses to start when it consumes MCLs and both UI indexing paths are off (`PRE_PROCESS_HOOKS_UI_ENABLED=false` and `PRE_PROCESS_HOOKS_REPROCESS_ENABLED` unset or false).
- **pgQueue idle sleep.** `DATAHUB_PGQUEUE_EMPTY_POLL_SLEEP_MS` and `DATAHUB_PGQUEUE_MCL_EMPTY_POLL_SLEEP_MS` are removed. Use the new min and per-topic max settings. pgQueue maintenance intervals must divide the clock (for example 15 minutes, not 7).
- **OpenAPI token recipes.** `get_token` is a typed object and cannot be combined with `token` or `bearer_token`.
- **Actions Kafka.** A pipeline whose Kafka source cannot connect stops, and the actions process exits, instead of staying up while consuming nothing.
- **Log line format.** `datahub-frontend`, `datahub-upgrade`, and GMS log lines no longer include the source line number.

#### Deprecations

- **OpenAPI v2 entity and relationship APIs** (`/openapi/v2/entity`, `/openapi/v2/relationship`) are deprecated in favor of `/openapi/v3/entity` and `/openapi/v3/relationship`. Timeseries, platform entity ingest, and timeline under v2 are not deprecated by this.
- **`semanticModelInfo.datasets`.** Membership is stored on the member. Datasets use `semanticModelProperties.semanticModel`. Metrics use `metricInfo.semanticModel`. Re-ingest Semantic Models after upgrade so metric-to-dataset lineage is populated. It is missing between the upgrade and that ingest.

#### Security

- Spring Framework 7.0.9, Spring Boot 4.0.8, Spring Security 7.0.7.
- Apache Parquet 1.18.1 (CVE-2026-73334).
- Apache Log4j 2.25.5 (CVE-2026-49844).
- Logback 1.5.38 (CVE-2026-9828, CVE-2026-10532).
- Apache Thrift `libthrift` 0.24.0 (CVE-2026-48586).
- pac4j 6.5.8 and play-pac4j 13.0.3 (CVE-2026-82461 through CVE-2026-82465).
- `acryl-datahub` no longer caps `setuptools`, so it installs alongside `setuptools>=83` (CVE-2026-59890).

#### Known Issues

None recorded in the v1.8.0 upgrade notes.


## [v1.6.0.3](https://github.com/datahub-project/datahub/releases/tag/v1.6.0.3) {#v1-6-0-3}

Released on 2026-09-25 by [@david-leifker](https://github.com/david-leifker).

### DataHub v1.6.0.3

Patch release for the **v1.6.0 LTS** line. Focus is security and authorization hardening, plus a few ingestion and platform fixes.

**Full diff:** https://github.com/datahub-project/datahub/compare/v1.6.0.2...v1.6.0.3

---

#### Operator notes

- **Python 3.11 is required** on this hotfix line (ingestion CLI/images and related packages). Python 3.10 is no longer supported for v1.6.0.x ([#19703](https://github.com/datahub-project/datahub/pull/19703)).
- **SecretService caller guard** defaults to `ENFORCE`. Secret encrypt/decrypt now requires an `OperationContext`; misconfigured callers fail closed instead of silently succeeding ([#17995](https://github.com/datahub-project/datahub/pull/17995)).
- **Opt-in frontend security headers.** Set `DATAHUB_SECURITY_HEADERS_FRAME_OPTIONS`, `DATAHUB_SECURITY_HEADERS_CONTENT_TYPE_OPTIONS`, and/or `DATAHUB_SECURITY_HEADERS_REFERRER_POLICY` to emit `X-Frame-Options`, `X-Content-Type-Options`, and `Referrer-Policy`. Unset vars omit those headers ([#19848](https://github.com/datahub-project/datahub/pull/19848)).

---

#### Security

Dependency floors and library bumps, including:

| Area | Fix |
| --- | --- |
| Snowflake connector | Floor raised to **4.7.3** (CVE-2026-15925, plus 4.7.1/4.7.2 TLS SAN regression for account locators with `_`) |
| aiohttp | **3.14.3** (CVE-2026-69244 / 59881 / 69243) |
| pip | **26.2+** (CVE-2026-13346) |
| click | **≥8.3.3** (CVE-2026-7246) |
| deepdiff | **≥8.6.2** (CVE-2026-33155) |
| unstructured | **0.24.1** (CVE-2026-71428) |
| libthrift | **0.24.0** (CVE-2026-48586) |
| MariaDB Connector/J | **2.7.14+** (CVE-2026-55856/557/558) |
| Bouncy Castle | **1.86** |
| Wolfi actions image | `WOLFI_PKG_REFRESH` bump (CVE-2026-85091 / zlib) |
| Java stack | Spring Framework **7.0.9**, Boot **4.0.8**, Security **7.0.7**; Jackson **2.22.x**; Parquet **1.18.1**; JJWT **0.13.0**; httpclient5, OTel, GitPython, cryptography / pyOpenSSL, anyio, soupsieve |

Also: setuptools **≥83** is allowed so consumers can take CVE-2026-59890 ([#19601](https://github.com/datahub-project/datahub/pull/19601)).

---

#### Authorization and secrets

- `patchEntity` / `patchEntities` authorize against the **URN’s entity type**, not the client-supplied `entityType` argument ([#19872](https://github.com/datahub-project/datahub/pull/19872)).
- **Manage User Credentials** is required to write `corpUserCredentials` (GraphQL, OpenAPI, Rest.li) ([#19967](https://github.com/datahub-project/datahub/pull/19967)).
- Asset settings, compliance form assignment, and raw analytics search require the intended privileges ([#19750](https://github.com/datahub-project/datahub/pull/19750)).
- `getSecretValues` no longer fails the whole batch when one secret cannot be decrypted ([#19539](https://github.com/datahub-project/datahub/pull/19539)).

---

#### Features

- **`semanticText` aspect** — optional curated text used as the embedding source for semantic search, instead of the entity’s full body ([#18654](https://github.com/datahub-project/datahub/pull/18654)).

---

#### Ingestion

- **confluent-kafka** raised to **2.15.1**.
- urllib3 2.x (needed by unstructured 0.24.1); vcrpy **≥8.2.0** for aiohttp 3.14 compatibility.

---

**Full Changelog:** https://github.com/datahub-project/datahub/compare/v1.6.0.2...v1.6.0.3

## [v1.7.0.1 🖖](https://github.com/datahub-project/datahub/releases/tag/v1.7.0.1) {#v1-7-0-1}

Released on 2026-09-03 by [@david-leifker](https://github.com/david-leifker).

### DataHub v1.7.0.1 🖖

Patch release for the v1.7.0 line: authorization tightening, CVE dependency bumps, entity-graph-cache and lineage correctness fixes, optional optimistic locking for aspect writes, and the remainder of the custom-assertion stack.

**Requirements**

- CLI / Python SDK: **1.7.0.9**
- Helm Chart: **1.1.0**

Full upgrade guidance, including every breaking change and migration step: [Updating DataHub — v1.7.0.1](https://docs.datahub.com/docs/how/updating-datahub#v1701).

**Upgrade path**

- **From v1.7.0:** drop-in image bump. No ZDU or Helm chart change is required. System-update runs a resumable backfill that copies embedded assertion notes to the new `assertionNote` aspect (tunable with `SYSTEM_UPDATE_ASSERTION_NOTE_MIGRATION_ENABLED`, `_BATCH_SIZE`, `_DELAY_MS`, `_LIMIT`).
- **From pre-1.7.0:** the v1.7.0 path still applies — you **must upgrade to v1.6.0 first** (Helm chart **1.0.3**, let system-update complete), then upgrade to v1.7.0.1 with Helm chart **1.1.0**. Do not skip 1.6.0.

**Model changes:** additive only. The `assertionNote` aspect is now registered on the `assertion` entity so ingestion can fully upsert `assertionInfo` without clobbering user-authored notes. Assertion URNs and run history are unchanged.

---

#### Action required before upgrading

| Area | What changed | Who is affected |
| --- | --- | --- |
| **System client secret** | The hardcoded `systemClientSecret` default (`JohnSnowKnowsNothing`) is removed from the server configs ([#18886](https://github.com/datahub-project/datahub/pull/18886)) | Set `DATAHUB_SYSTEM_CLIENT_SECRET` on GMS, MAE/MCE/PE consumers, the frontend, and Actions **before** upgrading if you still rely on the built-in default |
| **Timeseries reads** | Dataset profile / usage / operations timeseries (and dashboard usage stats) now require the matching **View Dataset Profile / Usage / Operations** privileges on Rest.li and OpenAPI as well as GraphQL ([#19508](https://github.com/datahub-project/datahub/pull/19508)) | API clients that previously read these aspects with only entity GET — grant the privileges or rely on the default `view-dataset-sensitive` policy |
| **Role & group membership writes** | `roleMembership` requires **Manage Policies**; `groupMembership` / `nativeGroupMembership` requires **Edit Group Members**; corpGroup `ownership` requires **Edit Owners** — checked at the aspect layer across GraphQL, OpenAPI, and Rest.li ([#19360](https://github.com/datahub-project/datahub/pull/19360)) | Automation writing membership outside the UI. Only additions are checked; removals, unchanged re-ingestion, and system writes pass. Toggle with `metadataChangeProposal.validation.aspectAuthorization.privilegeGrant.enabled` (default `true`) |
| **View authorization (VBAC)** | `container` and `schemaField` are view-restricted by default; schema-field View Entity Page inherits from the parent dataset ([#19212](https://github.com/datahub-project/datahub/pull/19212)) | Deployments with `VIEW_AUTHORIZATION_ENABLED=true` — ensure View Entity Page policies cover containers and parent datasets |

---

#### Security and authorization

- **Default self policy** ([#19297](https://github.com/datahub-project/datahub/pull/19297)) — limited to `VIEW_ENTITY_PAGE` and `GET_ENTITY` on the actor's own entity.
- **GMS `/auth` helpers** ([#19316](https://github.com/datahub-project/datahub/pull/19316)) — `signUp`, `resetNativeUserCredentials`, `verifyNativeUserCredentials`, and `getSsoSettings` now require system client credentials, matching `generateSessionTokenForUser`. Frontend login, signup, password reset, and SSO are unchanged.
- **System-write identification** ([#19384](https://github.com/datahub-project/datahub/pull/19384)) — aspect authorization no longer treats client-supplied `appSource` as proof of a system write.
- **Schema-field incidents** ([#19405](https://github.com/datahub-project/datahub/pull/19405)) — authorized against the parent entity.
- **Lineage scroll** ([#19463](https://github.com/datahub-project/datahub/pull/19463)) — unauthorized OpenAPI lineage scroll endpoints are redacted as restricted.
- **UI sanitization** ([#19298](https://github.com/datahub-project/datahub/pull/19298), [#19299](https://github.com/datahub-project/datahub/pull/19299), [#19300](https://github.com/datahub-project/datahub/pull/19300)) — query and incident descriptions, documentation PDF preview iframe `src`, and embed `renderUrl` schemes.
- **Ingestion secret masking** ([#19515](https://github.com/datahub-project/datahub/pull/19515), [#19526](https://github.com/datahub-project/datahub/pull/19526), [#19561](https://github.com/datahub-project/datahub/pull/19561), [#19332](https://github.com/datahub-project/datahub/pull/19332)) — masking is unified, idempotent, and fail-closed (mask before truncation; install once per process). Recorded HTTP cassettes are scrubbed.
- **AWS credentials** ([#19483](https://github.com/datahub-project/datahub/pull/19483)) — OpenSearch IAM signing, Bedrock embeddings, STS, and object storage share a process-wide credential provider and client lifecycle.

#### Reliability and performance

- **Entity-graph cache** ([#19498](https://github.com/datahub-project/datahub/pull/19498), [#19288](https://github.com/datahub-project/datahub/pull/19288), [#19301](https://github.com/datahub-project/datahub/pull/19301), [#19412](https://github.com/datahub-project/datahub/pull/19412)) — relationships are no longer silently dropped; indexed search fields are fetched for the cache; null relationship endpoints are skipped; hierarchy graph fallback batches frontier scrolls.
- **Container contents** ([#19489](https://github.com/datahub-project/datahub/pull/19489)) — `Container.relationships(types: [IsPartOf], direction: INCOMING)` again returns all contained entities from the live graph.
- **Lineage traversal** ([#19413](https://github.com/datahub-project/datahub/pull/19413)) — `scrollAcrossLineage` is bounded to prevent GMS OOM on wide graphs.
- **Case-insensitive `relatedEntityTypes`** ([#19268](https://github.com/datahub-project/datahub/pull/19268)).
- **Hot-path caching and batching** ([#19404](https://github.com/datahub-project/datahub/pull/19404), [#19476](https://github.com/datahub-project/datahub/pull/19476), [#18266](https://github.com/datahub-project/datahub/pull/18266)) — corpGroup `roleMembership` cached via `SystemEntityClient`, per-request CorpUserFlags served from a cached aspect, and Dashboard `usageStats` buckets and metrics batch-loaded across a page.
- **Optional optimistic locking for aspect writes** ([#19249](https://github.com/datahub-project/datahub/pull/19249)) — `OPTIMISTIC_LOCKING_ENABLED` replaces `SELECT FOR UPDATE` with compare-and-set on `SystemMetadata.version` for Ebean storage. `SCOPED_RETRY_ENABLED` retries only the conflicted URN's branch, and `ENTITY_WRITE_LOCK_BACKEND=hazelcast` serializes same-`(urn, aspect)` writers off the DB connection pool. PostgreSQL aspect writes also take row locks in consistent primary-key order. **All of these default off.**

#### Assertions

- **Custom-assertion stack completed on the 1.7 line** ([#18882](https://github.com/datahub-project/datahub/pull/18882)) — API/SDK, UI, the `assertionNote` aspect, and the dbt / Great Expectations / YAML data-contract writers. Those writers emit `AssertionType.CUSTOM` instead of the deprecated `DATASET` shape on the next run; **assertion URNs are unchanged and run history is preserved**. Assertions that are never re-ingested keep their stored `DATASET` aspects and continue to render. See [Custom Assertions](https://docs.datahub.com/docs/api/tutorials/custom-assertions).

#### Ingestion

- **nltk 3.10.1 excluded** ([#18889](https://github.com/datahub-project/datahub/pull/18889)) — that version silently breaks document chunking.
- **GitPython floor raised to 3.1.58** ([#19506](https://github.com/datahub-project/datahub/pull/19506)).
- **Bundled default CLI / Python SDK is 1.7.0.9** ([#19605](https://github.com/datahub-project/datahub/pull/19605)).

#### Dependency CVE bumps

- **Java:** httpclient5 5.6.3 (CVE-2026-64607), Spring Boot / Spring Kafka 4.0.7 (CVE-2026-41001), OpenTelemetry Java agent 2.28.0 (CVE-2026-54704), mariadb-java-client 2.7.14 (CVE-2026-55856 / 55857 / 55858), Logback 1.5.38 (CVE-2026-9828, CVE-2026-10532), Log4j 2.25.5 (CVE-2026-49844), Netty 4.2.17.Final (CVE-2026-59902), libthrift 0.23.0 (CVE-2026-43869), Jetty 12.1.10 (CVE-2026-10050), httpcore5 5.4.3 (CVE-2026-54399), micrometer-core 1.16.6 (CVE-2026-40983, CVE-2026-40984), wire-runtime 6.3.0 (CVE-2026-45799), reactor-netty-core 1.3.6, netty-reactive-streams 3.0.9.
- **Apache Parquet 1.18.0**, which refreshes its shaded Jackson to jackson-databind 2.22.1 (CVE-2026-54512, CVE-2026-54513).
- **Python / images:** nltk 3.10.3 (CVE-2026-12075); the `datahub-actions` image python layer is cache-busted so a stale cached layer stops shipping setuptools 70.3.0 (CVE-2025-47273).

---

#### Quickstart

`datahub docker quickstart` (and `--version v1.7.0`) resolves to the `v1.7.0.1` images once the version mapping update lands.

---

#### What's Changed

* fix(ingest): exclude nltk 3.10.1, which silently breaks document chunking by [@nwadams](https://github.com/nwadams) in https://github.com/datahub-project/datahub/pull/18889
* chore(release): backport custom assertion stack to v1.7.0 by [@AdrianMachado](https://github.com/AdrianMachado) in https://github.com/datahub-project/datahub/pull/18882
* feat(optimistic-locking): optimistic locking, aspect advisory locks, and Hazelcast write gate to v1.7.0 by [@Dutt23](https://github.com/Dutt23) in https://github.com/datahub-project/datahub/pull/19249
* fix(sec): bump wire-runtime 5.2.0 → 6.3.0 for CVE-2026-45799 by [@max-datahub](https://github.com/max-datahub) in https://github.com/datahub-project/datahub/pull/19317
* fix(sec): backport security fixes and CVE dependency bumps to v1.7.0 by [@supersingh05](https://github.com/supersingh05) in https://github.com/datahub-project/datahub/pull/19415
* fix(auth): backport graph-cache, timeseries auth, and related GMS fixes to v1.7.0 by [@david-leifker](https://github.com/david-leifker) in https://github.com/datahub-project/datahub/pull/19548
* fix(deps): bump mariadb-java-client to 2.7.14 for CVE-2026-55856/557/558 by [@david-leifker](https://github.com/david-leifker) in https://github.com/datahub-project/datahub/pull/19557
* fix(deps): bump httpclient5, Spring Boot, and OTel agent for v1.7.0.1rc1 CVEs by [@david-leifker](https://github.com/david-leifker) in https://github.com/datahub-project/datahub/pull/19565
* fix(gms): backport IRSA credential leak fix to v1.7.0 by [@david-leifker](https://github.com/david-leifker) in https://github.com/datahub-project/datahub/pull/19581
* fix(sec): backport ingestion secret-masking, GitPython, and image cache-bust fixes to v1.7.0 by [@supersingh05](https://github.com/supersingh05) in https://github.com/datahub-project/datahub/pull/19591
* chore(cli): bump default cli by [@david-leifker](https://github.com/david-leifker) in https://github.com/datahub-project/datahub/pull/19605

**Full Changelog**: https://github.com/datahub-project/datahub/compare/v1.7.0...v1.7.0.1

