---
title: Power BI Overview
description: >-
  Quick start guide for ingesting Power BI dashboards, reports, datasets, and
  lineage into DataHub via UI ingestion.
sidebar_label: Power BI Overview
slug: /quick-ingestion-guides/powerbi/overview
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/quick-ingestion-guides/powerbi/overview.md
---

# Power BI Ingestion Guide: Overview

## What You Will Get Out of This Guide

This guide will help you set up the Power BI connector to begin ingesting metadata into DataHub.

Upon completing this guide, you will have a recurring ingestion pipeline that will extract metadata from Power BI and load it into DataHub. This will include to following Power BI asset types:

- Dashboards
- Tiles
- Reports
- Pages
- Datasets
- Lineage

_To learn more about setting these advanced values, check out the [Power BI Ingestion Source](/docs/generated/ingestion/sources/powerbi)._

## Next Steps

Continue to the [setup guide](setup.md), where we'll describe the prerequisites.

## Advanced Guides and Reference

If you want to ingest metadata from Power BI using the DataHub CLI, check out the following resources:

- Learn about CLI Ingestion in the [Introduction to Metadata Ingestion](../../../metadata-ingestion/README.md)
- [Power BI Ingestion Source](/docs/generated/ingestion/sources/powerbi)
