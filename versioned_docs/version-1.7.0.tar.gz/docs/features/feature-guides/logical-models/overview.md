---
title: Logical Models
slug: /features/feature-guides/logical-models/overview
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/features/feature-guides/logical-models/overview.md
---
# Logical Models

:::note Supported Entity Types
Currently we only support datasets and by extension schema fields for logical models. No other entity types are supported.
:::

:::note Permissions
Creating a logical model and editing its **columns** require the **Create Logical Models** platform privilege, which is granted to the Admin role by default. Admins can grant it to other roles (e.g. Editor) via a custom platform policy. Linking or unlinking a physical child requires normal dataset **Edit** privileges on the affected datasets. Annotating a logical model (tags, glossary terms, owners, descriptions) requires normal dataset **Edit** privileges, and deleting one requires the **Delete** privilege — exactly like any dataset.
:::

## What is a Logical Model

A logical model represents the concept and structure of a database table, without being tied to any single physical instantiation in some source system. Like any DataHub dataset entity, a logical model describes its columns, including data types and descriptions, and can be attributed with other metadata like tags, terms, owners, and custom properties. But unlike physical datasets, logical models do not represent a table in a source system that actually exists, in which data is stored and can be queried.

Logical models are useful for those who have multiple tables that represent the same type or shape of data, or store the same data. This is common for multi-cloud data ecosystems, in which the same table may be replicated across several cloud providers, e.g. Snowflake, Redshift, and BigQuery. It is also useful in cases where multiple replicas exist in a single system, such as gold/silver/bronze layers. Logical models should be linked to each physical representation to expose this relationship in DataHub. DataHub Cloud customers can take advantage further with [Centralized Management](./centralized-management.md), in which every physical child's metadata can be managed at the logical model level.

## How It Looks

:::note Feature Flag
The environment variable `LOGICAL_MODELS_ENABLED` must be set to `true` on `datahub-gms` for logical models to be viewed in the UI.
:::

For example, suppose there exists a `Users` table Snowflake, an `AllUsers` table in BigQuery, and a `UsersAttributes` table Apache Hive. These three tables may have different names and slightly different structures, but logically represent the same data: a table of users, with certain information (columns) for each user. We create a logical table called `Users` and link it to each physical child:

<p style={{ display: "flex", flexDirection: "row", justifyContent: "center", gap: "60px" }}>
    <img width="40%" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/logical/relationship-diagram.png" />
</p>

Once the relationships are [created](#creating-logical-models), they will show up in the entity sidebar for both logical parents and their physical children:

<p style={{ display: "flex", flexDirection: "row", justifyContent: "center", gap: "60px" }}>
    <img width="40%" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/logical/logical-parent.png" />
    <img width="40%" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/logical/physical-child.png" />
</p>

Columns on the logical parent and physical children can be linked as well:

<p style={{ display: "flex", flexDirection: "row", justifyContent: "center", gap: "60px" }}>
    <img width="40%" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/logical/logical-parent-column.png" />
    <img width="40%" src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/logical/physical-child-column.png" />
</p>

## Creating Logical Models

Logical models are created like any DataHub dataset. We recommend using the Python SDK.

### From the UI

With `LOGICAL_MODELS_ENABLED`, logical models can also be created directly in the UI: use the **Create Logical Model** action in the search results controls bar, which opens a form for the model's name, platform, and columns. After creation, columns can be added, renamed, retyped, or deleted from the model's **Schema** tab.

:::note Logical Model Platform
A logical model is a dataset on a **logical platform** — a data platform marked as such — rather than being identified by an entity subtype. The platform picker offers existing logical platforms, including the built-in `logical` platform, or a custom name (up to 15 characters) that becomes a new logical platform. Logical models cannot be created on a regular, non-logical platform. If your logical models are stored in a system users are familiar with, we recommend creating a custom platform for that system and providing a custom icon. Otherwise, we recommend using the built-in `logical` platform, which has a special default icon.
:::

### Create Dataset in "logical" Platform

```python
    from datahub.sdk import DataHubClient, Dataset
    client = DataHubClient.from_env()
    dataset = Dataset(
        platform="logical",
        name=logical_model_name,
        description=logical_model_description,
        schema=[
            # tuples of (field name / field path, data type, description)
            (
                "zipcode",
                "varchar(50)",
                "This is the zipcode of the address. Specified using extended form and limited to addresses in the United States",
            ),
            ("street", "varchar(100)", "Street corresponding to the address"),
            ("date_column", "date", "Date of the last sale date for this property"),
        ],
    )
    client.entities.upsert(dataset)
```

### Create Dataset in Custom Platform

```python
    # Create custom platform with custom logo
    from datahub.sdk import DataHubClient
    from datahub.emitter.mcp import MetadataChangeProposalWrapper
    from datahub.metadata.schema_classes import DataPlatformInfoClass, PlatformTypeClass
    from datahub.metadata.urns import DataPlatformUrn

    urn = DataPlatformUrn("<platformName>").urn()
    aspect = DataPlatformInfoClass(
        name="<platformName>",
        type=PlatformTypeClass.OTHERS,
        datasetNameDelimiter=".",
        logoUrl="<url>"
    )
    client = DataHubClient.from_env()
    client._graph.emit(MetadataChangeProposalWrapper(entityUrn=urn, aspect=aspect))

    # Create dataset in custom platform
    from datahub.sdk import DataHubClient, Dataset
    client = DataHubClient.from_env()
    dataset = Dataset(
        platform="<platformName>",
        ...  # See above
    )
    client.entities.upsert(dataset)
```

## Linking Logical Models

At its core, the logical -> physical relationship is created by the [`LogicalParent`](../../../generated/metamodel/entities/dataset.md#logicalparent) aspect. To link columns, this aspect must also be created on each child schema field entity. However, for ease of use, we recommend the OpenAPI endpoint.

### From the UI

On a logical model's profile, the **Physical Children** sidebar section provides actions to link a physical dataset (with optional column mapping) and to unlink existing children. Editing a logical model's columns in a breaking way (removing, renaming, or retyping a column) only tears down the child column mappings that referenced the changed column: a child keeps its link, along with any other unaffected column mappings, as long as at least one mapping survives, and is fully unlinked only if none do. Adding a column is non-breaking and never affects existing links. There is no automatic re-linking after a breaking change — affected children must be re-linked manually against the new schema.

### OpenAPI

The OpenAPI endpoint creates a logical -> physical relationship for a single logical-physical pair, as well as the column-level relationships between their columns, if specified.

```shell
curl -X POST 'http://localhost:8080/openapi/v3/logical/<physical_child_urn>/relationship/physicalInstanceOf/<logical_model_urn>' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "<logical_column_name_0>": "<physical_column_name_0>",
    "<logical_column_name_1>": "<physical_column_name_1>",
    "<logical_column_name_2>": "<physical_column_name_2>"
  }'
```

These relationships can also be removed (as of DataHub Cloud v0.3.15):

```shell
curl -X DELETE 'http://localhost:8080/openapi/v3/logical/<physical_child_urn>/relationship/physicalInstanceOf' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json'
```

### Python SDK

The Python SDK can also query the same endpoint:

```python
    from datahub.sdk import DataHubClient
    client = DataHubClient.from_env()
    url = f"{client._graph.config.server}/openapi/v3/logical/{child_urn}/relationship/physicalInstanceOf/{parent_urn}"
    client._graph._post_generic(url, {column.parent_name: column.child_name for column in columns})
```

Or it can create a single relationship by emitting the `LogicalParent` aspect.

```python
    from datahub.sdk import DataHubClient
    from datahub.emitter.mcp import MetadataChangeProposalWrapper
    from datahub.metadata.schema_classes import EdgeClass, LogicalParentClass
    client = DataHubClient.from_env()

    client._graph.emit(MetadataChangeProposalWrapper(entityUrn=child_urn, aspect=LogicalParentClass(parent=EdgeClass(destinationUrn=parent_urn))))
```

The relationship can also be removed:

```python
    from datahub.sdk import DataHubClient
    from datahub.emitter.mcp import MetadataChangeProposalWrapper
    from datahub.metadata.schema_classes import EdgeClass, LogicalParentClass
    client = DataHubClient.from_env()

    client._graph.emit(MetadataChangeProposalWrapper(entityUrn=child_urn, aspect=LogicalParentClass(parent=None)))
```

## Authorization

Linking or unlinking a physical dataset to a logical parent writes the [`LogicalParent`](../../../generated/metamodel/entities/dataset.md#logicalparent) aspect on the **child** entity (dataset and, for column links, schema field). Authorization requires **Edit Entity** on **both** the child and proposed parent when setting a link; clearing a parent requires **Edit Entity** on the child only.

Each side is checked independently: **datasets** require **Edit Entity** on that dataset; **schema fields** accept **Edit Entity** on the containing dataset or on the schema field URN. The child and parent sides may use different grant types (for example, a dataset policy on the physical side and a schema-field policy on the logical side). OpenAPI logical-model endpoints apply the same rules before batch-writing MCPs.

This applies to MCP ingestion, GraphQL (`setLogicalParent`), and OpenAPI relationship endpoints.

See [Metadata Policies — derived authorization rules](../../../authorization/policies.md#logical-parent-logicalparent-aspect).
