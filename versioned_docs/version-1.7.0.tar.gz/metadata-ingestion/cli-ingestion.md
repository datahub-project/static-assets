---
description: >-
  Run scheduled batch metadata ingestion from the CLI using DataHub recipes to
  extract metadata from source systems in bulk.
title: CLI Ingestion
slug: /metadata-ingestion/cli-ingestion
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/metadata-ingestion/cli-ingestion.md
---

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

# CLI Ingestion

Batch ingestion involves extracting metadata from a source system in bulk. Typically, this happens on a predefined schedule using the [Metadata Ingestion](../docs/components.md#ingestion-framework) framework.
The metadata that is extracted includes point-in-time instances of dataset, chart, dashboard, pipeline, user, group, usage, and task metadata.

## Installing DataHub CLI

On macOS or Linux, the simplest install is via Homebrew:

```bash
brew install datahub-project/tap/datahub
datahub version
```

Or via pip on any platform:

:::note Required Python Version
Installing DataHub CLI via pip requires Python 3.10+.
:::

```bash
python3 -m pip install --upgrade pip wheel setuptools
python3 -m pip install --upgrade acryl-datahub
python3 -m datahub version
```

Your command line should return the proper version of DataHub upon executing these commands successfully.

Check out the [CLI Installation Guide](../docs/cli.md#installation) for more installation options and troubleshooting tips.

## Installing Connector Plugins

Our CLI follows a plugin architecture. You must install connectors for different data sources individually.
For a list of all supported data sources, see [the open source docs](../docs/cli.md#sources).
Once you've found the connectors you care about, simply install them using `pip install`.
For example, to install the `mysql` connector, you can run

```shell
pip install --upgrade 'acryl-datahub[mysql]'
```

Check out the [alternative installation options](../docs/cli.md#alternate-installation-options) for more reference.

:::tip Building a new connector?

If you need a connector that doesn't exist yet, [datahub-skills](./datahub-skills.md) is a
Claude Code plugin that accelerates connector development — from planning and scaffolding to
standards review and community testing.

:::

## Configuring a Recipe

Create a [Recipe](recipe_overview.md) yaml file that defines the source and sink for metadata, as shown below.

<Tabs>
<TabItem value="oss" label="OSS / Self-Hosted" default>

No token is needed when authentication is disabled.

```yaml
# example-recipe.yml

# MySQL source configuration
source:
  type: mysql
  config:
    username: root
    password: password
    host_port: localhost:3306

# Recipe sink configuration.
sink:
  type: "datahub-rest"
  config:
    server: "http://localhost:8080"
```

</TabItem>

<TabItem value="cloud" label="DataHub Cloud">

```yaml
# example-recipe.yml

# MySQL source configuration
source:
  type: mysql
  config:
    username: root
    password: password
    host_port: localhost:3306

# Recipe sink configuration.
sink:
  type: "datahub-rest"
  config:
    server: "https://<your-instance>.acryl.io/gms"
    token: <your-token>
```

</TabItem>
</Tabs>

For Docker and Kubernetes server addresses, see the [DataHub sink reference](sink_docs/datahub.md).

The **source** configuration block defines where to extract metadata from. This can be an OLTP database system, a data warehouse, or something as simple as a file. Each source has custom configuration depending on what is required to access metadata from the source. To see configurations required for each supported source, refer to the [Sources](source_overview.md) documentation.

The **sink** configuration block defines where to push metadata into. Each sink type requires specific configurations, the details of which are detailed in the [Sinks](sink_overview.md) documentation.

Set the `server` field to the address of your DataHub instance's GMS API: `http://localhost:8080` for a local OSS deployment, or `https://<your-instance>.acryl.io/gms` for DataHub Cloud.

For more information and examples on configuring recipes, please refer to [Recipes](recipe_overview.md).

### Using Recipes with Authentication

In DataHub Cloud deployments, only the `datahub-rest` sink is supported, which simply means that metadata will be pushed to the REST endpoints exposed by your DataHub instance. The required configurations for this sink are

1. **server**: the location of the REST API exposed by your instance of DataHub
2. **token**: a unique API key used to authenticate requests to your instance's REST API

Any user with the **Generate Personal Access Tokens** platform privilege can create one. Navigate to **Settings → Access Tokens** and click **Generate Personal Access Token**, choosing your desired expiration date.

<p align="center">
  <img width="70%"  src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/saas/home-(1).png"/>
</p>

<p align="center">
  <img width="70%"  src="https://raw.githubusercontent.com/datahub-project/static-assets/main/imgs/saas/settings.png"/>
</p>

:::info Secure Your API Key
Please keep Your API key secure & avoid sharing it.
If you are on DataHub Cloud and your key is compromised for any reason, please reach out to the DataHub team at support@acryl.io.
:::

## Ingesting Metadata

The final step requires invoking the DataHub CLI to ingest metadata based on your recipe configuration file.
To do so, simply run `datahub ingest` with a pointer to your YAML recipe file:

```shell
datahub ingest -c <path/to/recipe.yml>
```

## Scheduling Ingestion

Ingestion can either be run in an ad-hoc manner by a system administrator or scheduled for repeated executions. Most commonly, ingestion will be run on a daily cadence.
To schedule your ingestion job, we recommend using a job schedule like [Apache Airflow](https://airflow.apache.org/). In cases of simpler deployments, a CRON job scheduled on an always-up machine can also work.
Note that each source system will require a separate recipe file. This allows you to schedule ingestion from different sources independently or together.
Learn more about scheduling ingestion in the [Scheduling Ingestion Guide](/metadata-ingestion/schedule_docs/intro.md).

## Reference

Please refer the following pages for advanced guides on CLI ingestion.

- [Reference for `datahub ingest` command](../docs/cli.md#ingest)
- [UI Ingestion Guide](../docs/ui-ingestion.md)

:::tip Compatibility

DataHub server uses a 3 digit versioning scheme, while the CLI uses a 4 digit scheme. For example, if you're using DataHub server version 1.5.0, you should use CLI version 1.5.0.7, where the last digit is a patch version.
We do this because we do CLI releases at a much higher frequency than server releases — CLI patches ship roughly weekly, while server releases happen roughly every couple of months.

For ingestion sources, any breaking changes will be highlighted in the [release notes](../docs/how/updating-datahub.md). When fields are deprecated or otherwise changed, we will try to maintain backwards compatibility for two server releases, which is about 4-6 weeks. The CLI will also print warnings whenever deprecated options are used.
:::
