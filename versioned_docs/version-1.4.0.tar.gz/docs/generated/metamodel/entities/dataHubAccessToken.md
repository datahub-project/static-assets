---
sidebar_position: 54
title: DataHubAccessToken
slug: /generated/metamodel/entities/datahubaccesstoken
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/generated/metamodel/entities/dataHubAccessToken.md
---
# DataHubAccessToken
import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

## Technical Reference Guide

The sections above provide an overview of how to use this entity. The following sections provide detailed technical information about how metadata is stored and represented in DataHub.

**Aspects** are the individual pieces of metadata that can be attached to an entity. Each aspect contains specific information (like ownership, tags, or properties) and is stored as a separate record, allowing for flexible and incremental metadata updates.

**Relationships** show how this entity connects to other entities in the metadata graph. These connections are derived from the fields within each aspect and form the foundation of DataHub's knowledge graph.

### Reading the Field Tables

Each aspect's field table includes an **Annotations** column that provides additional metadata about how fields are used:

- **⚠️ Deprecated**: This field is deprecated and may be removed in a future version. Check the description for the recommended alternative
- **Searchable**: This field is indexed and can be searched in DataHub's search interface
- **Searchable (fieldname)**: When the field name in parentheses is shown, it indicates the field is indexed under a different name in the search index. For example, `dashboardTool` is indexed as `tool`
- **→ RelationshipName**: This field creates a relationship to another entity. The arrow indicates this field contains a reference (URN) to another entity, and the name indicates the type of relationship (e.g., `→ Contains`, `→ OwnedBy`)

Fields with complex types (like `Edge`, `AuditStamp`) link to their definitions in the [Common Types](#common-types) section below.

### Aspects

#### dataHubAccessTokenInfo
Information about a DataHub Access Token

<Tabs>
<TabItem value="fields" label="Fields" default>


| Field | Type | Required | Description | Annotations |
|-------|------|----------|-------------|-------------|
| name | string | ✓ | User defined name for the access token if defined. | Searchable |
| actorUrn | string | ✓ | Urn of the actor to which this access token belongs to. | Searchable |
| ownerUrn | string | ✓ | Urn of the actor which created this access token. | Searchable |
| createdAt | long | ✓ | When the token was created. | Searchable |
| expiresAt | long |  | When the token expires. | Searchable |
| description | string |  | Description of the token if defined. |  |

</TabItem>
<TabItem value="raw" label="Raw Schema">

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataHubAccessTokenInfo"
  },
  "name": "DataHubAccessTokenInfo",
  "namespace": "com.linkedin.access.token",
  "fields": [
    {
      "Searchable": {
        "fieldType": "TEXT_PARTIAL"
      },
      "type": "string",
      "name": "name",
      "doc": "User defined name for the access token if defined."
    },
    {
      "Searchable": {
        "fieldType": "URN"
      },
      "java": {
        "class": "com.linkedin.common.urn.Urn"
      },
      "type": "string",
      "name": "actorUrn",
      "doc": "Urn of the actor to which this access token belongs to."
    },
    {
      "Searchable": {
        "fieldType": "URN"
      },
      "java": {
        "class": "com.linkedin.common.urn.Urn"
      },
      "type": "string",
      "name": "ownerUrn",
      "doc": "Urn of the actor which created this access token."
    },
    {
      "Searchable": {
        "fieldType": "COUNT",
        "queryByDefault": false
      },
      "type": "long",
      "name": "createdAt",
      "doc": "When the token was created."
    },
    {
      "Searchable": {
        "fieldType": "COUNT",
        "queryByDefault": false
      },
      "type": [
        "null",
        "long"
      ],
      "name": "expiresAt",
      "default": null,
      "doc": "When the token expires."
    },
    {
      "type": [
        "null",
        "string"
      ],
      "name": "description",
      "default": null,
      "doc": "Description of the token if defined."
    }
  ],
  "doc": "Information about a DataHub Access Token"
}
```

</TabItem>
</Tabs>


### Relationships

### [Global Metadata Model](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
![Global Graph](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
