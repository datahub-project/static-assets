---
title: DataHub Town Halls
sidebar_label: Town Halls
slug: /townhalls
custom_edit_url: 'https://github.com/datahub-project/datahub/blob/master/docs/townhalls.md'
---
# DataHub Town Halls

We hold virtual Town Hall meetings with the DataHub Community every other month (with some exceptions due to holidays).

It's a great opportunity for the Community to come together to discuss project and roadmap updates, see live demos of upcoming features, and hear case studies from other Community Members.

[Register for the January Town Hall](https://events.datahub.com/january-townhall-2026/)

## Upcoming Events

Check out our DataHub Community Calendar to RSVP to office hours and upcoming events!

<p align="center">
  <iframe
    src="https://lu.ma/embed/calendar/cal-lom9HnTVnZkKsNh/events"
    width="80%"
    height="450"
    frameborder="0"
    allowfullscreen=""
    aria-hidden="false"
    tabindex="0"
  ></iframe>
</p>

## Town Hall History

See our Town Hall Playlist on YouTube for recordings of past town halls.

- [View the playlist here](https://www.youtube.com/watch?v=aVWJsw7RJ8c&list=PLdCtLs64vZvHTXGqybmOfyxXbGDn2Reb9)
