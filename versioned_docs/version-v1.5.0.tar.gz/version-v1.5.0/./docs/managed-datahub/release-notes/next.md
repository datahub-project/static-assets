---
title: Next
slug: /managed-datahub/release-notes/next
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/docs/managed-datahub/release-notes/next.md
---
# Next

:::info

<!-- This contains detailed release notes, but there is also an [announcement blog post](https://datahub.com/blog/next/) that covers the highlights. -->

:::

#### Release Availability Date

TBD

#### Recommended Versions

- **CLI/SDK**: TBD
- **Remote Executor**: TBD
- **On-Prem Versions**:
  - **Helm**: TBD
  - **API Gateway**: TBD
  - **Actions**: TBD

## Release Changelog

### Next

New Features:

- TODO

Fixes:

- TODO

## Known Issues

- TODO
