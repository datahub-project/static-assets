---
sidebar_position: 51
title: DataHubRetention
slug: /generated/metamodel/entities/datahubretention
custom_edit_url: null
---
# DataHubRetention
import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

## Technical Reference Guide

The sections above provide an overview of how to use this entity. The following sections provide detailed technical information about how metadata is stored and represented in DataHub.

**Aspects** are the individual pieces of metadata that can be attached to an entity. Each aspect contains specific information (like ownership, tags, or properties) and is stored as a separate record, allowing for flexible and incremental metadata updates.

**Relationships** show how this entity connects to other entities in the metadata graph. These connections are derived from the fields within each aspect and form the foundation of DataHub's knowledge graph.

### Reading the Field Tables

Each aspect's field table includes an **Annotations** column that provides additional metadata about how fields are used:

- **⚠️ Deprecated**: This field is deprecated and may be removed in a future version. Check the description for the recommended alternative
- **Searchable**: This field is indexed and can be searched in DataHub's search interface
- **Searchable (fieldname)**: When the field name in parentheses is shown, it indicates the field is indexed under a different name in the search index. For example, `dashboardTool` is indexed as `tool`
- **→ RelationshipName**: This field creates a relationship to another entity. The arrow indicates this field contains a reference (URN) to another entity, and the name indicates the type of relationship (e.g., `→ Contains`, `→ OwnedBy`)

Fields with complex types (like `Edge`, `AuditStamp`) link to their definitions in the [Common Types](#common-types) section below.

### Aspects

#### dataHubRetentionKey
Key for a DataHub Retention

<Tabs>
<TabItem value="fields" label="Fields" default>


| Field | Type | Required | Description | Annotations |
|-------|------|----------|-------------|-------------|
| entityName | string | ✓ | Entity name to apply retention to. * (or empty) for applying defaults. |  |
| aspectName | string | ✓ | Aspect name to apply retention to. * (or empty) for applying defaults. |  |

</TabItem>
<TabItem value="raw" label="Raw Schema">

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataHubRetentionKey"
  },
  "name": "DataHubRetentionKey",
  "namespace": "com.linkedin.metadata.key",
  "fields": [
    {
      "type": "string",
      "name": "entityName",
      "doc": "Entity name to apply retention to. * (or empty) for applying defaults."
    },
    {
      "type": "string",
      "name": "aspectName",
      "doc": "Aspect name to apply retention to. * (or empty) for applying defaults."
    }
  ],
  "doc": "Key for a DataHub Retention"
}
```

</TabItem>
</Tabs>


#### dataHubRetentionConfig
None

<Tabs>
<TabItem value="fields" label="Fields" default>


| Field | Type | Required | Description | Annotations |
|-------|------|----------|-------------|-------------|
| retention | Retention | ✓ |  |  |

</TabItem>
<TabItem value="raw" label="Raw Schema">

```javascript
{
  "type": "record",
  "Aspect": {
    "name": "dataHubRetentionConfig"
  },
  "name": "DataHubRetentionConfig",
  "namespace": "com.linkedin.retention",
  "fields": [
    {
      "type": {
        "type": "record",
        "name": "Retention",
        "namespace": "com.linkedin.retention",
        "fields": [
          {
            "type": [
              "null",
              {
                "type": "record",
                "name": "VersionBasedRetention",
                "namespace": "com.linkedin.retention",
                "fields": [
                  {
                    "type": "int",
                    "name": "maxVersions"
                  }
                ],
                "doc": "Keep max N latest records"
              }
            ],
            "name": "version",
            "default": null
          },
          {
            "type": [
              "null",
              {
                "type": "record",
                "name": "TimeBasedRetention",
                "namespace": "com.linkedin.retention",
                "fields": [
                  {
                    "type": "int",
                    "name": "maxAgeInSeconds"
                  }
                ],
                "doc": "Keep records that are less than X seconds old"
              }
            ],
            "name": "time",
            "default": null
          }
        ],
        "doc": "Base class that encapsulates different retention policies.\nOnly one of the fields should be set"
      },
      "name": "retention"
    }
  ]
}
```

</TabItem>
</Tabs>


### Relationships

### [Global Metadata Model](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)
![Global Graph](https://github.com/datahub-project/static-assets/raw/main/imgs/datahub-metadata-model.png)


:::note 💡 **Contributing to this documentation**
This page is auto-generated from the underlying source code. To make changes, please edit the relevant source files in the [metadata-models](https://github.com/datahub-project/datahub/tree/master/metadata-models) directory. 

**Tip:** For quick typo fixes or documentation updates, you can click the ✏️ **Edit** icon directly in the GitHub UI to open a Pull Request. For larger changes and PR naming conventions, please refer to our [Contributing Guide](/docs/contributing).
:::
