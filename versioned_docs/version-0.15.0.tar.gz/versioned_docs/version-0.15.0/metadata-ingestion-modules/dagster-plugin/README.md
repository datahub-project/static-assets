---
title: Datahub Dagster Plugin
slug: /metadata-ingestion-modules/dagster-plugin
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/metadata-ingestion-modules/dagster-plugin/README.md
---
# Datahub Dagster Plugin

See the DataHub Dagster docs for details.

