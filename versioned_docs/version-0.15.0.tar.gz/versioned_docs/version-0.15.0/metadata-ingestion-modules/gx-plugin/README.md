---
title: Datahub GX Plugin
slug: /metadata-ingestion-modules/gx-plugin
custom_edit_url: >-
  https://github.com/datahub-project/datahub/blob/master/metadata-ingestion-modules/gx-plugin/README.md
---
# Datahub GX Plugin

See the DataHub GX docs for details.

